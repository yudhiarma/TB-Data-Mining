lokasi_kerja <- "E:/TBDataMining"
setwd(lokasi_kerja)
getwd()
dataset <- read.csv("Salary_Data.csv", sep = ",")
install.packages("C50")
install.packages("printr")
head(dataset)
dataset$Salary<-as.factor(dataset$Salary)
model <-C5.0(Salary ~., data=dataset)
model
summary(model)
plot(model)
datatesting <-dataset[,1:3]
predictions <-predict(model, datatesting)
table(predictions, dataset$Salary)
