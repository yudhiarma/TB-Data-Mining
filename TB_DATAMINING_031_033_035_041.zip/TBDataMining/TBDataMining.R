lokasi_kerja <- "E:/TBDataMining"
setwd(lokasi_kerja)
getwd()
dataset <- read.csv("Salary_Data.csv", sep = ",")
head(dataset)
cor(dataset$YearsExperience, dataset$Salary)
linearMod <- lm(Salary ~ YearsExperience, data=dataset)
summary(linearMod)
print(linearMod)
databaru.YearsExperience <- data.frame(
  YearsExperience = c(1.5)
)
predict(linearMod, newdata = databaru.YearsExperience)
databaru.YearsExperience <- data.frame(
  YearsExperience = c(1.5,2.0,1.1)
)
predict(linearMod, newdata = databaru.YearsExperience)
